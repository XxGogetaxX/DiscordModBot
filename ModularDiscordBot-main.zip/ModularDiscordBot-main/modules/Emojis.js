module.exports = {
    greenTick: "<:greentick:466238645095890945>",
    redTick: "<:redtick:466238619997175811>",
    yellowTick: "<:yellowtick:517062281805299712>"
}